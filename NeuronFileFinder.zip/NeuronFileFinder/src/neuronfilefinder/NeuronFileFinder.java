package neuronfilefinder;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import javax.swing.JFileChooser;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.ParseException;


public class NeuronFileFinder {
    private static File root =null;
    private static NDirectory rootDir;


    public static void main(String[] args) {
        findRoot();    
        System.out.println("Root Established");
        recordBeforeQuiting();
        System.out.println("Done");
    }
    
    public static void findRoot()
    {
        FileReader jsonIn;
        BufferedReader jsonReader;
        String line =null;
        String metaDataJSON = "";
        try 
        {
            String jsonStorage = "MetaDataStorage.txt";
            jsonIn = new FileReader(jsonStorage);
            jsonReader = new BufferedReader(jsonIn);
            line = jsonReader.readLine();
            while(line != null) 
            {
                metaDataJSON+=(line);
                line = jsonReader.readLine();
            }   
            jsonReader.close();
        }
        catch (FileNotFoundException ex) 
        {
        try 
            {
                FileWriter temp = new FileWriter("MetaDataStorage.txt");
                temp.write("");
                temp.close();
            }
            catch (IOException exx) 
                {
                    Logger.getLogger(NeuronFileFinder.class.getName()).log(Level.SEVERE, null, ex);
                }    
        } 
        catch (IOException ex) 
        {
            Logger.getLogger(NeuronFileFinder.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Read in this:");
        System.out.println(metaDataJSON);
        JSONParser parser = new JSONParser();
         try
         {
         JSONObject metaData = (JSONObject)parser.parse(metaDataJSON);
         JSONObject files = (JSONObject)metaData.get(1);
         JSONObject rootData = (JSONObject)files.get(1);
         root = new File((String) rootData.get("location"));
         }
         catch(ParseException pe)
         {	
            System.out.println("No Valid JSON found");
            setRoot();
         }
     
    }
    
    public static void setRoot()
    {
        JFileChooser OPEN = new JFileChooser();
        OPEN.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        OPEN.showOpenDialog(null);
        root = OPEN.getSelectedFile();
        rootDir = new NDirectory(root);
        System.out.println("Root Set");
    }

    public static MetaData snoop(File target)
    {
        String name = target.getName();
            String location =target.getAbsolutePath();
            Path filePath = target.toPath();
            BasicFileAttributes attr;
            String creationDate = null;
            try
            {
                attr = Files.readAttributes(filePath, BasicFileAttributes.class);
                creationDate = attr.creationTime().toString();
            } 
            catch (IOException ex) 
            {
                Logger.getLogger(NeuronFileFinder.class.getName()).log(Level.SEVERE, null, ex);
            }  
            
        if(!target.isDirectory())
        {
            long size =target.getTotalSpace();
            NFile newFile = new NFile(name,size,location,creationDate);
            return newFile;
        }
        else
        {   
            long totalSize = 0;
            for(File subTarget:target.listFiles())
            {
               totalSize+=snoop(target).getSize(); 
            }
            NDirectory newFile = new NDirectory(name,totalSize,location,creationDate); 
            return newFile;
        }
        }
    
     public static JSONObject toJSON()
    {
      JSONObject metadata = new JSONObject();
      JSONObject rootJSON = new JSONObject();
      JSONObject temp = rootDir.toJSON();
      rootJSON.put("Root",temp); //rootDir.toJSON()
      metadata.put("Files", rootJSON);      
      return metadata;
    }
     
     public static void recordBeforeQuiting()
     {
        FileWriter jsonOut;
        try 
        {
            jsonOut = new FileWriter("MetaDataStorage.txt");
            jsonOut.write(NeuronFileFinder.toJSON().toJSONString());
            jsonOut.close();
        }
        catch (IOException ex) 
        {
            System.out.println("Error here");
            Logger.getLogger(NeuronFileFinder.class.getName()).log(Level.SEVERE, null, ex);
        }

     }
    }

