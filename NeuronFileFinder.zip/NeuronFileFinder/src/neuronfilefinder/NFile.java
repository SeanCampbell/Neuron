package neuronfilefinder;
import java.util.ArrayList;
import org.json.simple.JSONObject;

public class NFile extends MetaData{
    ArrayList<String> tags;
    
    public NFile()
    {
        super();
        tags = new ArrayList<String>();
    }
    
    public NFile(String fn)
    {
        super(fn);
        tags = new ArrayList<String>();
    }
    public NFile(String fn, long fs)
    {
        super(fn,fs);
        tags = new ArrayList<String>();
    }
    
    public NFile(String fn, String cd)
    {
        super(fn,cd);
        tags = new ArrayList<String>();

    }
    public NFile(String fn, long fs, String cd)
    {
        super(fn,fs,cd);
        tags = new ArrayList<String>();


    }
    
    public NFile(String fn, long fs,String loc, String cd)
    {
        super(fn,fs,loc,cd);
        tags = new ArrayList<String>();

    
    }
    
    public void addTag(String newTag)
    {
        tags.add(newTag);
    }
    
    public boolean removeTag(String tagForRemoval)
    {
        return tags.remove(tagForRemoval);
    }
    
    public ArrayList<String> getTags()
    {
        return tags;
    }
    
     public JSONObject toJSON()
    {
      JSONObject obj = super.toJSON();
      obj.put("Tags", this.getTags());
      return obj;
    }
}
