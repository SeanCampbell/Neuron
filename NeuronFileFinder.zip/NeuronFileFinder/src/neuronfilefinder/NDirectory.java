package neuronfilefinder;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import static neuronfilefinder.NeuronFileFinder.snoop;
import org.json.simple.JSONObject;

public class NDirectory extends MetaData {//implements Iterable{
    ArrayList<MetaData> contents;
    
    public NDirectory()
    {
        super();
        contents = new ArrayList<>();
    }
    
    public NDirectory(File target)
    {
        super(target);
        contents = new ArrayList<>();
        for(File subTarget:target.listFiles())
            {
               MetaData temp =snoop(subTarget);
               fileSize += temp.getSize();
               contents.add(temp);
            }
    }
    
    public NDirectory(String fn)
    {
        super(fn);
        contents = new ArrayList<MetaData>();
    }
    
    public NDirectory(String fn, long fs)
    {
        super(fn,fs);
        contents = new ArrayList<MetaData>();
    }
    
    
    public NDirectory(String fn, String cd)
    {
        super(fn,cd);
        contents = new ArrayList<MetaData>();

    }
    public NDirectory(String fn, long fs, String cd)
    {
        super(fn,fs,cd);
        contents = new ArrayList<MetaData>();
    }
    
    public NDirectory(String fn, long fs,String loc, String cd)
    {
        super(fn,fs,loc,cd);
        contents = new ArrayList<MetaData>();
    }
    
    
    public boolean addElement(MetaData newElement)
    {
        return contents.add(newElement);
    }
    
    public boolean removeElement(MetaData toBeRemoved)
    {
        return contents.remove(toBeRemoved);
    }
    
    public boolean removeElement(String toBeRemoved)
    {
        for(MetaData content:contents)
        {
            if(content.getName().equals(toBeRemoved))
            {
                if(contents.remove(content))
                {
                    return true;
                }
            }
        }
        return false;
    }
    
    private void recalculateSize()
    {
        long newSize =0;
        for(MetaData content:contents)
        {
            newSize+=content.getSize();
        }
        this.updateSize(newSize);
    }
    
    public JSONObject toJSON()
    {
      recalculateSize();
      JSONObject obj = super.toJSON();
      ArrayList<JSONObject> contentsAsJSON = new ArrayList();
      for(MetaData content:contents)
        {
            contentsAsJSON.add(content.toJSON());
        } 
      System.out.println("Contents as JSON->"+contentsAsJSON);
      obj.put("Contains", contentsAsJSON);
 
      return obj;
    }
}

