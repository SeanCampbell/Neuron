package neuronfilefinder;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONObject;

public class MetaData {
    protected String fileName;
    protected long fileSize;
    protected String location;
    protected String creationDate;
    
    public MetaData()
    {
        fileName = "Default";
        fileSize = 0;
        location ="Default";
        creationDate ="Default";
    }
    
     public MetaData(File target)
    {
        fileName = target.getName();
        Path targetPath = target.toPath();
        fileSize = 0;
        location =targetPath.toString();//target.getAbsolutePath();
        creationDate ="Default";
        BasicFileAttributes attr;
            try
            {
                attr = Files.readAttributes(targetPath, BasicFileAttributes.class);
                creationDate = attr.creationTime().toString();
            } 
            catch (IOException ex) 
            {
                Logger.getLogger(NeuronFileFinder.class.getName()).log(Level.SEVERE, null, ex);
            }  
    }
    
    public MetaData(String fn)
    {
        fileName = fn;
        fileSize = 0;
        location ="Default";
        creationDate ="Default";

    }
    
    public MetaData(String fn, long fs)
    {
        fileName = fn;
        fileSize = fs;
        location ="Default";
        creationDate ="Default";
    }
     
    public MetaData(String fn, String cd)
    {
        fileName = fn;
        fileSize = 0;
        location ="Default";
        creationDate =cd;
    }
    public MetaData(String fn, long fs, String cd)
    {
        fileName = fn;
        fileSize = fs;
        location ="Default";
        creationDate =cd;
    }
    
    public MetaData(String fn, long fs,String loc, String cd)
    {
        fileName = fn;
        fileSize = fs;
        location =loc;
        creationDate =cd;
    }
    
    public void updateName(String fn)
    {
        fileName = fn;
    }
    
    public void updateSize(long fs)
    {
        fileSize = fs;
    }
    
    public String getName()
    {
        return fileName;
    }
    
    public long getSize()
    {
        return fileSize;
    }
    
    public String getCreationDate()
    {
        return creationDate;
    }
    
    public String getLocation()
    {
        return location;
    }

    public JSONObject toJSON()
    {
      JSONObject obj = new JSONObject();
      obj.put("Created On", this.getCreationDate());
      obj.put("File Size", this.getSize());
      obj.put("Location", this.getLocation());
      obj.put("File Name", this.getName());
      return obj;
    }
  
}
